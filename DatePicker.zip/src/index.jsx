import React from "react";
import Client from "react-dom/client";
import App from "./components/App"

const root = Client.createRoot(document.getElementById("root"))
root.render(
    <>
        <App />
    </>
)