import React, { useRef, useState } from "react";
import "../tailwind/App.css"
import DateTime from "../libs/DateTime"
import { toPersianNumber, toEnglishNumber } from "../libs/Utillities"

const DatePicker = (props) => {
    const yearInputRef = useRef()
    const monthInputRef = useRef()
    const calendarRef = useRef()
    const dateTimeNow = props.type === "jalali" ? new DateTime().toShamsi() : new DateTime()
    const [selectedYear, setSelectedYear] = useState(dateTimeNow.getYear())
    const [selectedMonth, setSelectedMonth] = useState(dateTimeNow.getMonth())
    const [selectedDay, setSelectedDay] = useState(dateTimeNow.getDay())
    
    const fillYearOptions = () => {
        let years = []

        for (let i = dateTimeNow.getYear(); i > dateTimeNow.getYear() - props.until; i--) {
            years.push(i)
        }

        const yearOptions = years.map(year => {
            return (
                <option value={year} key={year}>
                    {(props.type === "jalali") ? toPersianNumber(year) : year}
                </option>
            )
        })

        return yearOptions
    }

    const fillMonthOptions = () => {
        if (props.type === "jalali") {
            return (
                <>
                    <option value="1">
                        فروردین
                    </option>
                    <option value="2">
                        اردیبهشت
                    </option>
                    <option value="3">
                        خرداد
                    </option>
                    <option value="4">
                        تیر
                    </option>
                    <option value="5">
                        مرداد
                    </option>
                    <option value="6">
                        شهریور
                    </option>
                    <option value="7">
                        مهر
                    </option>
                    <option value="8">
                        آبان
                    </option>
                    <option value="9">
                        آذر
                    </option>
                    <option value="10">
                        دی
                    </option>
                    <option value="11">
                        بهمن
                    </option>
                    <option value="12">
                        اسفند
                    </option>
                </>
            )
        } else {
            return (
                <>
                    <option value="1">
                        January
                    </option>
                    <option value="2">
                        February
                    </option>
                    <option value="3">
                        March
                    </option>
                    <option value="4">
                        April
                    </option>
                    <option value="5">
                        May
                    </option>
                    <option value="6">
                        June
                    </option>
                    <option value="7">
                        July
                    </option>
                    <option value="8">
                        August
                    </option>
                    <option value="9">
                        September
                    </option>
                    <option value="10">
                        October
                    </option>
                    <option value="11">
                        November
                    </option>
                    <option value="12">
                        December
                    </option>
                </>
            )
        }
    }

    const setMonthValue = () => {
        return dateTimeNow.getMonth()
    }

    const setDays = () => {
        const daysCount = DateTime.getDaysCount(selectedYear, selectedMonth, "gregorian")
        let skipDaysCount = (props.type === "jalali") ? new DateTime(selectedYear, selectedMonth, 1).toMiladi().getDayOfWeek() : new DateTime(selectedYear, selectedMonth, 1).getDayOfWeek("gregorian")
        let days = []
        let button = <></>

        for (let i = 0; i < skipDaysCount; i++) {
            days.push(0)
        }

        for (let i = 1; i <= daysCount; i++) {
            days.push(i)
        }

        const daysButtons = days.map(day => {
            if (day === 0) {
                button = (
                    <button className="day disabled" draggable="false" key={"Disabled_" + skipDaysCount}></button>
                )

                skipDaysCount -= 1
            } else {
                if (selectedMonth >= 7 && selectedMonth <= 11) {
                    if (selectedDay === 31) {
                        setSelectedDay(30)
                    }
                } else if (selectedMonth === 12) {
                    if (DateTime.isLeap(selectedYear)) {
                        if (selectedDay === 31) {
                            setSelectedDay(30)
                        }
                    } else {
                        if (selectedDay === 31 || selectedDay === 30) {
                            setSelectedDay(29)
                        }
                    }
                }

                button = (
                    <button className={"day" + (props.type === "jalali" ? " font-rtl" : " font-ltr") + ((day === selectedDay) ? (props.theme === "purple" ? " active-purple" : "") + (props.theme === "blue" ? " active-blue" : "") + (props.theme === "yellow" ? " active-yellow" : "") : "") + (props.theme === "purple" ? " btn-purple" : "") + (props.theme === "blue" ? " btn-blue" : "") + (props.theme === "yellow" ? " btn-yellow" : "")} key={day} onClick={() => setSelectedDay(day)}>
                        {(props.type === "jalali") ? toPersianNumber(day) : day}
                    </button>
                )
            }

            return button
        })

        return daysButtons
    }

    const onInputClick = () => {
        if (calendarRef.current.style.display === "block") {
            calendarRef.current.style.display = "none"
        } else {
            calendarRef.current.style.display = "block"
        }
    }

    document.addEventListener("click", (event) => {
        if (event.target.id !== "datePickerInput" && event.target !== yearInputRef.current && event.target !== monthInputRef.current) {
            calendarRef.current.style.display = "none"
        }
    })

    return (
        <div className="datepicker" dir={(props.type === "jalali") ? "rtl" : "ltr"}>
            <input type="text" id="datePickerInput" className={"input w-[350px]" + (props.type === "jalali" ? " font-rtl" : " font-ltr") + (props.theme === "purple" ? " input-purple" : "") + (props.theme === "blue" ? " input-blue" : "") + (props.theme === "yellow" ? " input-yellow" : "")} value={(props.type === "jalali") ? toPersianNumber(selectedYear + "/" + selectedMonth + "/" + selectedDay) : selectedYear + "/" + selectedMonth + "/" + selectedDay} onClick={onInputClick} readOnly />
            <div className="calendar" style={{ display: "none" }} ref={calendarRef}>
                <div className="config">
                    <div className="flex justify-between">
                        <select className={"input-select" + (props.type === "jalali" ? " font-rtl" : " font-ltr") + (props.theme === "purple" ? " input-purple" : "") + (props.theme === "blue" ? " input-blue" : "") + (props.theme === "yellow" ? " input-yellow" : "")} defaultValue={setMonthValue()} onChange={() => setSelectedMonth(Number(monthInputRef.current.value))} ref={monthInputRef}>
                            {fillMonthOptions()}
                        </select>
                        <select className={"input-select" + (props.type === "jalali" ? " font-rtl" : " font-ltr") + (props.theme === "purple" ? " input-purple" : "") + (props.theme === "blue" ? " input-blue" : "") + (props.theme === "yellow" ? " input-yellow" : "")} onChange={() => setSelectedYear(Number(yearInputRef.current.value))} ref={yearInputRef}>
                            {fillYearOptions()}
                        </select>
                    </div>
                    <div className="week-days">
                        {
                            props.type === "jalali" ? (
                                <>
                                    <div className="week-name">
                                        ش
                                    </div>
                                    <div className="week-name">
                                        ی
                                    </div>
                                    <div className="week-name">
                                        د
                                    </div>
                                    <div className="week-name">
                                        س
                                    </div>
                                    <div className="week-name">
                                        چ
                                    </div>
                                    <div className="week-name">
                                        پ
                                    </div>
                                    <div className="week-name">
                                        ج
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="week-name">
                                        Su
                                    </div>
                                    <div className="week-name">
                                        Mo
                                    </div>
                                    <div className="week-name">
                                        Tu
                                    </div>
                                    <div className="week-name">
                                        We
                                    </div>
                                    <div className="week-name">
                                        Th
                                    </div>
                                    <div className="week-name">
                                        Fr
                                    </div>
                                    <div className="week-name">
                                        Sa
                                    </div>
                                </>
                            )
                        }
                    </div>
                </div>
                <div className="days font-rtl">
                    {setDays(dateTimeNow.getYear(), dateTimeNow.getMonth(), dateTimeNow.getDay())}
                </div>
            </div>
        </div>
    )
}

export default DatePicker