/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/index.html", "./src/tailwind/App.css", "./src/components/DatePicker.jsx"],
  theme: {
    extend: {
      fontFamily: {
        'firasans': "Fira Sans",
        'shabnam': "Shabnam"
      },
      colors: {
        'focus-purple': 'rgba(190, 136, 224, 0.3)',
        'focus-blue': 'rgba(60, 148, 255, 0.290)',
        'focus-yellow': 'rgba(239, 206, 21, 0.327)',
        'bg-blue': 'rgb(82, 108, 255)',
        'bg-yellow': 'rgb(235, 204, 31)'
      }
    },
  },
  plugins: [],
}
