import React from "react";
import DatePicker from "./DatePicker";

const App = () => {
    return (
        <DatePicker until="80" type="jalali" theme="purple" />
    )
}

export default App